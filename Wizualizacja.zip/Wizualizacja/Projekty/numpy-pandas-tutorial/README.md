# Numpy and pandas tutorial for data data visualization in python.

This is set of lessons which will teach you numpy and pandas basics. The aim of the course is to prapare you to visualize the data. You will learn how to

## Why I have created this course?

In the beginning, it was created for teaching "Data Visualization Course" at [Department of Computer Science of University of Warmia and Mauzury](http://wmii.uwm.edu.pl) but with time more people start to use it for self-learning. I have also used it for workshops and other courses. Then I have decided to improve it and share. The process of improving is constant so if you want to contribute do not hesitate



## Prerequisits:
* python 3 syntax: list, loops, functions
* linear algebra fundamentals: vectos, matrix, matrix arithmetic (addition, multiplication)




## What 

Some numpy examples was inspired and taken from http://cs231n.github.io/python-numpy-tutorial/
Some pandas examples was takent from [10 minuts to pandas](https://pandas.pydata.org/pandas-docs/stable/10min.html)


* Numpy
    * how to create numpy arrays
    * how to create numpy 2d and 3https://pandas.pydata.org/pandas-docs/stable/10min.html)d arrays
    * how should I understand the 3d array indexes
    * reshaping and slicing 3d arrays
    
* Pandas
    * how to create dataframe
    * different ways to create dataframe
